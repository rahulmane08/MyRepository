package iterator;

public class MenuItem {
	private String item;

	public MenuItem(String item) {
		super();
		this.item = item;
	}

	@Override
	public String toString() {
		return "MenuItem [item=" + item + "]";
	}
	
}
