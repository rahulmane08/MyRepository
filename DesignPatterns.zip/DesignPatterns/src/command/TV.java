package command;

public class TV extends Appliances {

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("TV turned on");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("TV turned off");
	}

}
