package command;

public abstract class Appliances {
	public abstract void on();
	public abstract void off();
}
