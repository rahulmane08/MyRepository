package command;

public class Fan extends Appliances {

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("Fan turned on");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("Fan turned off");
	}

}
