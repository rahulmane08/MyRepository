package command;

public class AC extends Appliances {

	@Override
	public void on() {
		// TODO Auto-generated method stub
		System.out.println("AC turned on");
	}

	@Override
	public void off() {
		// TODO Auto-generated method stub
		System.out.println("AC turned off");
	}

}
