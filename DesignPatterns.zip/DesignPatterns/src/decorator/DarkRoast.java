package decorator;

public class DarkRoast extends Beverage {

	@Override
	public int getCost() {
		// TODO Auto-generated method stub
		return 10;
	}
	
	@Override
	public String getDescription() {
		// TODO Auto-generated method stub
		return "Dark Roast Coffee";
	}

}
