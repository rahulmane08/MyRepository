package decorator;

public abstract class Condiment extends Beverage {

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	public abstract String getDescription();
}
