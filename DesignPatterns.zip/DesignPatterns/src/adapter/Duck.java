package adapter;

public interface Duck {
	public void fly();
	public void quack();
}
