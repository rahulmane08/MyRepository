package adapter;

public class MallardDuck implements Duck {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("flying mallard duck");
	}

	@Override
	public void quack() {
		// TODO Auto-generated method stub
		System.out.println("quack of mallard duck");
	}

}
