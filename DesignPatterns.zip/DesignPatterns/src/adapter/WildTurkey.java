package adapter;

public class WildTurkey implements Turkey {

	@Override
	public void fly() {
		// TODO Auto-generated method stub
		System.out.println("flying wild turkey");
	}

	@Override
	public void gobble() {
		// TODO Auto-generated method stub
		System.out.println("gobble of a wild turkey");
	}

}