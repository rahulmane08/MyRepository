package strategy;

public class Quack implements Quackable {

	@Override
	public String quack() {
		// TODO Auto-generated method stub
		return " quacks!";
	}

}
