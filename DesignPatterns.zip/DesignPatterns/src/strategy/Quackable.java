package strategy;

public interface Quackable {
	public String quack();
}
