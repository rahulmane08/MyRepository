package strategy;

public interface Flyable {
	public String fly();
}
