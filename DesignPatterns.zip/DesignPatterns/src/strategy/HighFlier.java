package strategy;

public class HighFlier implements Flyable {

	@Override
	public String fly() {
		// TODO Auto-generated method stub
		return " is a high flier";
	}

}
