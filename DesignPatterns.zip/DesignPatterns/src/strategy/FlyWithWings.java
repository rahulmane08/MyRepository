package strategy;

public class FlyWithWings implements Flyable {

	@Override
	public String fly() {
		// TODO Auto-generated method stub
		return " flies with wings";
	}

}
