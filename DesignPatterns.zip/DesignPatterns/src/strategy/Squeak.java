package strategy;

public class Squeak implements Quackable {

	@Override
	public String quack() {
		// TODO Auto-generated method stub
		return " squeaks!";
	}

}
